export const environment = {
  production: true,
  api: 'http://localhost:3000'
};
